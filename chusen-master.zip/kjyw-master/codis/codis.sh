#!/bin/bash
##robert yu
##centos 6
##codis搭建

#  快速搭建codis，可以参考这个项目
#  https://github.com/ppabc/codis_quick
#  