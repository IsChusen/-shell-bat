# harbor

## docker快速安装harbor
- 有问题可以反馈 https://aq2.cn/ 
- harbor复制同步功能出现internal server error错误 https://aq2.cn/202.html

## docker快速安装harbor
- 先安装docker docker-18.09.8
```
curl -s https://gitee.com/aqztcom/kjyw/raw/master/docker/install-docker-18.09.8.sh | bash
```

## 快速安装docker-compose
- 先安装docker-compose
```
curl -s https://gitee.com/aqztcom/kjyw/raw/master/docker/install-docker-compose.sh | bash
```
## 安装harbor
- 安装harbor
```
bash install-harbor.sh
```