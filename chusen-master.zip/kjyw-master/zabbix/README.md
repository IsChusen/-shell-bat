# docker快速安装zabbix 

## docker快速安装zabbix:4.4.7
- 管理员账号Admin   密码admin
- 有问题可以反馈 https://aq2.cn/189.html

```
bash docker-zabbix-4.4.7.sh
```

## docker快速安装zabbix-3.4.15
管理员账号Admin   密码admin
```
bash docker-zabbix-3.4.15.sh
```