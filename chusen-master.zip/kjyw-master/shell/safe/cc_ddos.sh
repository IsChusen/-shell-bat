#!/bin/bash
##robert yu
##centos 6
##DDOS、CC攻击 处理

#  收集处理DDOS、CC攻击各类脚本，包括NGINX日志中的CC攻击IP处理，可以参考这个项目
#  https://github.com/ppabc/cc_iptables
#  